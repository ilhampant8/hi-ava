export default {
  nicknames: ["Bre", "won", "su", "koe kabeh", "syg"],
  greetings: {
    evening: "Good Evening",
    afternoon: "Good Afternoon",
    day: "Good Day",
    morning: "Good Morning",
    night: "Good Night"
  }
};
